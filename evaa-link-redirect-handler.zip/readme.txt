=== EVAA Link Redirect Handler ===
Contributors: Gabtoof
Tags: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
Offer a link redirect service to bypass Facebook Canadian content sharing.
 
== Description ==
 
Offer a link redirect service to bypass Facebook Canadian content sharing.
 
== Installation ==
 
1. Upload plugin.
2. Activate the plugin through the 'Plugins' menu in WordPress
4. Use shortcode [evaa_link_redirect]
 
== Changelog ==

= 1.0.6 =
* Update plugin update library. Correct updater code.
 
= 1.0 =
* Initial release.